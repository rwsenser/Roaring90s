
import java.io.*;

/**
  Translate.java -- copy a small to another file,
                    allowing for encoding changes.
 */
 
 /*
 The MIT License (MIT)

Copyright (c) 2013 Robert Senser

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

 */
public class Translate {

  public int count;

  /**
   * Constructor
   */
  public Translate( String inData,
                    String inEnc,
                    String outData,
                    String outEnc,
                    String option) {

    InputStreamReader isr;
    OutputStreamWriter osw;
    BufferedReader br;
    String line;
    int ch;

    count = 0;

    try {

      isr = new InputStreamReader( new FileInputStream(inData), inEnc);
      osw = new OutputStreamWriter( new FileOutputStream( outData), outEnc);

      while ((ch = isr.read()) != -1) {
        osw.write(ch);
        if (option.equals("-v")) {
          System.out.println("" + count + " --> " + AsHex(ch));
        }
        count++;
      }

      isr.close();
      osw.close();

    } catch (Exception e) {
      System.out.println("error: " + e);
    }

  }

  public static String AsHex(int value) {
    String digits = "0123456789abcdef";
    String result = "";

    while (value > 0) {
      int remainder = value % 16;
      value = value / 16;
      result = digits.charAt(remainder) + result;
    }

    return "0x" + result;
  }
  /**
   * main
   * @param args
   */
  public static void main(String[] args) {

    System.out.println("Translate running.");
    String options;

    if (args.length != 4 &&
        args.length != 5) {
      System.out.println("Invalid command line values");
      System.out.println("usage:  Transalte <in> <inEnc> <out> <outEnc> <-v>");
    } else {
      if (args.length == 4) {
        options = "";
      } else {
        options = args[4];
      }
      Translate tr = new Translate(args[0], args[1], args[2], args[3], options);
      System.out.println("" + tr.count + " characters translated.");

    }
  }
}


