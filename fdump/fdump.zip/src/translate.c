// translate.c
//
// translate a small file using ICU
//
// usage:  translate <in> <inEnc> <out> <outEnc>
// 
// no real error handling..........
//
/*
The MIT License (MIT)

Copyright (c) 2013 Robert Senser

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/


#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>

// for ICU
#include <unicode/utypes.h>		/* Basic ICU data types */
#include <unicode/ucnv.h>		/* C Converter API */
#include <unicode/ustring.h>	/* ?? */
#include <unicode/uloc.h>		/* ?? */

#define SRC_BUF_LEN  10000
#define UNI_BUF_LEN  30000
#define DST_BUF_LEN  (SRC_BUF_LEN * 2)

unsigned char srcBuffer [ SRC_BUF_LEN ],
              dstBuffer [ DST_BUF_LEN ];

UChar 		  uniBuffer [ UNI_BUF_LEN ];

main ( int argc, char * argv[] ) {


	int i;

	UConverter	*cSrc;
	UConverter	*cTrg;
	UErrorCode	status = U_ZERO_ERROR;

	FILE* inFile;
	FILE* outFile;

	int inUsed = -1;
	int outUsed;
	int ch;

	long uniLength;

	// off to the races........
	if (argc != 5 && argc != 6) {
		printf("bad input parms.....\n");
		printf("usage: translate <in> <inEnc> <out> <outEnc> [-v]\n");
		exit(99);
	}

	// open files.....
	inFile = fopen(argv[1], "rb");
	if (inFile == NULL) {
		printf("open error: %s\n", argv[1]);
		exit(99);
	}

	outFile = fopen(argv[3], "wb");
	if (outFile == NULL) {
		printf("open error: %s\n", argv[3]);
		exit(99);
	}

	// read the input
	for (i=0; i < SRC_BUF_LEN; i++) {
		ch = fgetc(inFile);
		if (ch < 0) {
			inUsed = i;
			break;
		}
		srcBuffer[i] = (unsigned char) ch;
	}

	// minimal checking....
	if (inUsed < 0) {
		printf("ERROR:, no input data or buffer overflow\n");
		exit(99);
	}

	printf("input characters read: %d\n", inUsed);


	// open the converters
	cSrc = ucnv_open(argv[2], &status);
	if (status != U_ZERO_ERROR) {
		printf("Error: %s ucnv_open status: %d\n", argv[2], status);
	}

	cTrg = ucnv_open(argv[4], &status);
	if (status != U_ZERO_ERROR) {
		printf("Error: %s ucnv_open status: %d\n", argv[4], status);
	}

	// first translation, whatever to UChar
	uniLength = ucnv_toUChars(	cSrc,
							uniBuffer,
							UNI_BUF_LEN,
							srcBuffer,
							inUsed,
							&status);
	if (status != U_ZERO_ERROR) {
		printf("Error: ucnv_toUChars status: %d\n", status);
		exit(99);
	}

	// toss the terminator
	uniLength--;

	printf("characters in Unicode buffer: %d\n", uniLength);

	if (argc == 6) {
		for (i=0; i < uniLength; i++) {
			printf("%i --> %x\n", i, uniBuffer[i]);
		}
	}

	// second translation, UChar to whatever
	outUsed = ucnv_fromUChars(cTrg,
							dstBuffer,
							DST_BUF_LEN,
							uniBuffer,
							uniLength,
							&status);


	if (status != U_ZERO_ERROR) {
		printf("Error: cnv_fromUChars status: %d\n", status);
		exit(99);
	}

	// done with converters	
	ucnv_close(cSrc);
	ucnv_close(cTrg);

	// toss terminator character
	// outUsed--;

	// output the results...
	for (i=0; i < outUsed; i++) {
		ch = (int) dstBuffer[i]; 
		fputc(ch, outFile);
	}

	printf("output characters written: %d\n", outUsed);

	fclose(inFile);
	fclose(outFile);

	return(0);

}
