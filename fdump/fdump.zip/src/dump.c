// dump.c
//
// hex dump a small file 
//
// usage:  dump <in> // 
//
/*
The MIT License (MIT)

Copyright (c) <2013 Robert Senser

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/


#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>


#define SRC_BUF_LEN  10000

unsigned char srcBuffer [ SRC_BUF_LEN ];

main ( int argc, char * argv[] ) {


	int i;


	FILE* inFile;

	int inUsed = -1;
	int ch;

	if (argc != 2) {
		printf("bad input parms.....\n");
		printf("usage: dump <in>\n");
		exit(99);
	}

	// open files.....
	inFile = fopen(argv[1], "rb");
	if (inFile == NULL) {
		printf("open error: %s\n", argv[1]);
		exit(99);
	}

	// read the input
	for (i=0; i < SRC_BUF_LEN; i++) {
		ch = fgetc(inFile);
		if (ch < 0) {
			inUsed = i;
			break;
		}
		srcBuffer[i] = (unsigned char) ch;
	}

	// minimal checking....
	if (inUsed < 0) {
		printf("ERROR:, no input data or buffer overflow\n");
		exit(99);
	}

	printf(" chars read: %d", inUsed);

	// out it goes...

	for (i=0; i < inUsed; i++) {
		if ((i % 32) == 0) {
			printf("\n");
		}

		printf("%2.2x ", srcBuffer[i]);

	}

	fclose(inFile);

	return(0);

}
