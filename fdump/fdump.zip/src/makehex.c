// makehex.c
//
// create a small file using hex input 
//
// usage:  dump <in> // 
//
/*
The MIT License (MIT)

Copyright (c) 2013 Robert Senser

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>


main ( int argc, char * argv[] ) {


	unsigned int i, j;


	FILE* outFile;

	int outUsed = -1;
	unsigned char ch[] = { 0, 0 };
	unsigned char byte;
	unsigned int num;

	if (argc != 3) {
		printf("bad input parms.....\n");
		printf("usage: makehex <file> <hexdata>\n");
		printf("sample: makehex myjunk.txt  ff830000\n");
		exit(99);
	}

	if ((strlen(argv[2]) % 2) != 0) {
		printf("error: bad hex data, must be in terms of full bytes...\n");
		exit(99);
	}

	// open files.....
	outFile = fopen(argv[1], "wb");
	if (outFile == NULL) {
		printf("open error: %s\n", argv[1]);
		exit(99);
	}

	// convert and write the data
	for (i=0; i < ( strlen(argv[2]) / 2) ; i++) {
		j = i * 2;
		ch[0] = argv[2][j];
		sscanf(ch, "%x", &num);
		byte = (unsigned char) num;
		// printf("DEBUG byte1: %x\n", byte);
		ch[0] = argv[2][j+1];
		sscanf(ch, "%x", &num);
		// printf("DEBUG num2: %x\n", ((unsigned char) num));
		byte = byte * 16 + num;
		fputc((int) byte , outFile);
		// printf("DEBUG: %x\n", byte);
	}

	fclose(outFile);

	return(0);

}
